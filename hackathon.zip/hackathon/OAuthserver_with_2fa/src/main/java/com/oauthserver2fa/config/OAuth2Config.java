package com.oauthserver2fa.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;

@Configuration
public class OAuth2Config extends AuthorizationServerConfigurerAdapter {

	//@Value("${config.oauth2.clientid}")
	private String clientid;

	//@Value("${config.oauth2.clientSecret}")
	private String clientSecret;

	//@Value("${config.oauth2.privateKey}")
	private String privateKey;

	//@Value("${config.oauth2.publicKey}")
	private String publicKey;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	@Qualifier("authenticationManagerBean")
	private AuthenticationManager authenticationManager;

	@Override
	public void configure(AuthorizationServerSecurityConfigurer security) throws Exception {
		security.tokenKeyAccess("permitAll()").checkTokenAccess("isAuthenticated()");
	}

	@Override
	public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
		clients.inMemory().withClient("talk2amareswaran").secret(passwordEncoder.encode("talk2amareswaran@123")).scopes("read", "write")
				.authorizedGrantTypes("password", "refresh_token").accessTokenValiditySeconds(3600)
				.refreshTokenValiditySeconds(18000);
	}

	@Override
	public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
		endpoints.authenticationManager(authenticationManager).tokenStore(tokenStore())
				.accessTokenConverter(tokenEnhancer());
	}

	@Bean
	public JwtTokenStore tokenStore() {
		return new JwtTokenStore(tokenEnhancer());
	}

	@Bean
	public JwtAccessTokenConverter tokenEnhancer() {
		JwtAccessTokenConverter converter = new CustomTokenEnhancer();
		converter.setSigningKey("-----BEGIN RSA PRIVATE KEY-----MIIEpgIBAAKCAQEArJs9DHCcsqevTqYR5Jp9tzNldaBqfTGW03NmUpsm7iylLDtX0RXbB/v+KxeRLGQg052DVnMAPCPYuH7aoyG28rYydE/4zZL7OnlTl5GUnDq9p5Sz0fokku0yYZh/mOlzjzOVXUZeMb9O563kHwHW/ebnYjIHakBrKa1j222UPz9qa36+d4jUwW5H4U5Lbe2RhT9KfQQiUYQQikVe7aRn45mo5aN8PkCQVz9m17SYDAwx+ZOnVq73OTAcRUO8vF1mtrYpwH4ge6ClUTPAo2KXCa4NtMswgC8Mrod8c/41jYi50gcem0sKTSFw7JA2aRzs7VgMPFbINVBFUb6sj+DZCQIDAQABAoIBAQCXkiLD38faoqGxQOgJhRjMXZfE+T9J/NfjizzZYWGIWTAabWoqMzUKB+EkWiejgbHJ4lHJAme8aAYRzWOVSS/sZs5bkTZ834s5x/z95ltH7dVJaa2WwECJvT02ssGpt6dAox2QsRBaQxK5I9xk1irC/5dEhYY5aaQxDw/XSpyaBFaYOWd2TOEo0NSESNXh8trmjA5aRN/xEpqJsKfD1AARK7VgKvdtwu6GCEr521FirsVgk3gaDimTNWtYTxTGHd/To+jJIx8V36ujcX2sAzVCmfOuavtfTigNpjcDLS6XdrshpHnGnFqHq2P5HEbIe8IwhAf3Q+KpOEKEpoZH6MoZAoGBANuS8cQeLSMOb0lYwDkOXfx/Mn2N9BYygo3P15+7wpXjNerT81YWhAF9vUoKl+j456cujkDzm0amxOHOzT7S6uroKSIvQ2NI4RJy0YJ1e5luipc6dmuOxlYr6f7BfbdKJfLlVOCBc9TVUOisK0IJ3OBjKOXjEqvep1JxFjED2jCfAoGBAMk9ok3zqxuR+xUt4jKH8r1vSKTe9pfcRR4kT5Sz1gGOvsv+KtpYDW1L1cEDo1irvuFcKBpFDLdoR7OlCyrNprvR81j8BBGBypcCchLq06uiK5xgMuadivMvm859d+ZuR4hxKN9h/dnFQos9EyaUx1h9Kt5Om8vInxerfwm9Vc1XAoGBAJe0jxXRQ55U+s7SYv0I0CcEOv5EdcBgZZNVZsUWFPs6YKY+ioGQTOQ62+2sJAjy8BqyL9bwePf3gVACcgxV7bkfbkwQG58dW2RDsD1SrnLzzQ1vdyIZIy+mZ6V8Sj+5Gz8W8+2pgz4ppB0d10VpSxI9cKRknyHgU/rB53M2FipBAoGBAJAgdVKw9lY7mgDUKNGZ7i7gOb3i9edTWak5xkkw90+MRXfiJBzWvV8O1htzmJSUBJRwpUQTOgVNSTUPOk1Alm6j8k5DyEIlm8vFc5+60Th2YBeSCkKCiJac/VDJKYs+ZjsBGI3MJ7vE/GCusD2Mhq0IkCBBWnF70P1p1QVLtdznAoGBAKSxya7Mqip1jl5LHW9MLdqceNjZGABZ/M2nOwDHbhuzbHLI2gGjDTKTZ4sBaNYJ9t+alExNh+h7q6n1TV/uvAgVSj5F6H7F3WsVYH0ySbqJzZxQaJcCzy8vUHY3pxv4f1z36a6IPXRFZ5eGdANxYDC8NDIyh3ZzcWktH8fFZxSj-----END RSA PRIVATE KEY-----");
		converter.setVerifierKey("-----BEGIN PUBLIC KEY-----MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArJs9DHCcsqevTqYR5Jp9tzNldaBqfTGW03NmUpsm7iylLDtX0RXbB/v+KxeRLGQg052DVnMAPCPYuH7aoyG28rYydE/4zZL7OnlTl5GUnDq9p5Sz0fokku0yYZh/mOlzjzOVXUZeMb9O563kHwHW/ebnYjIHakBrKa1j222UPz9qa36+d4jUwW5H4U5Lbe2RhT9KfQQiUYQQikVe7aRn45mo5aN8PkCQVz9m17SYDAwx+ZOnVq73OTAcRUO8vF1mtrYpwH4ge6ClUTPAo2KXCa4NtMswgC8Mrod8c/41jYi50gcem0sKTSFw7JA2aRzs7VgMPFbINVBFUb6sj+DZCQIDAQAB-----END PUBLIC KEY-----");
		return converter;
	}

}
