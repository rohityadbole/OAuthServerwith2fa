package com.oauthserver2fa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OAuthserverWith2faApplication {

	public static void main(String[] args) {
		SpringApplication.run(OAuthserverWith2faApplication.class, args);
	}

}
